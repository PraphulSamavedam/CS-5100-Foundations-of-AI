list_with_parameters=[(120,'B'), (190,'C'), (100,'D'), (30,'Z'), (20,'A')]
print(min(list_with_parameters))